// function sum(...numbers:number[]):number{
//       return numbers.reduce((sumall,curr)=>{
//            return sumall+curr;
//       },0)
// }

// console.log(sum(0));
// console.log(sum(1,2,3,4,5,5,6,7,))




// function sumtwo(num:number,num2 ?:number):number
// {
//       if(num2)
//             return num+num2;
//       else
//       return num

// }
// console.log(sumtwo(2));
// console.log(sumtwo(2,6));



  // find maximux element 
/// 24 65 34 90
//   function max(...number:number[]):number{
//       return number.reduce((prev,curr)=>{
//             if(curr>prev)
//              return curr
//             return prev

//       })
//   }
  
// console.log(max(12, 54, 98 ,12))

/// find minimum 
// function min(...number:number[]):number{
//       return number.reduce((prev,curr)=>{
//             if(curr<prev)
//              return curr
//             return prev

//       })
//   }
// console.log(min(12, 54, 98 ,12))
